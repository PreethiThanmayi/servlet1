package com.cg.login.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.cg.login.exception.ExceptionMessages;
import com.cg.login.exception.LoginException;

public class DBConnection {
	 private static Connection connection=null;

	public static Connection getConnection() {
 if(connection==null)
 {
	 try
	 {
		 
	 
	 connection=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg703","training703");
			 
	 }
	 catch(SQLException se)
	 {
		 try {
			throw new LoginException(ExceptionMessages.MESSAGE1);
		} catch (LoginException e) {
			
			e.printStackTrace();
		}
	 }
 }
		return connection;
	}

}
