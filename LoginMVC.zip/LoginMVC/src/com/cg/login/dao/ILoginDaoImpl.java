package com.cg.login.dao;

import java.sql.Connection;

import com.cg.login.bean.LoginBean;
import com.cg.login.util.DBConnection;

public class ILoginDaoImpl implements ILoginDao {

	@Override
	public boolean verifyLogin(LoginBean loginBean) {
boolean result=false;
Connection connection=DBConnection.getConnection();
		return result;
	}

}
