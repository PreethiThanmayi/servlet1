package com.cg.login.dao;

import com.cg.login.bean.LoginBean;

public interface ILoginDao {

	boolean verifyLogin(LoginBean loginBean);

}
