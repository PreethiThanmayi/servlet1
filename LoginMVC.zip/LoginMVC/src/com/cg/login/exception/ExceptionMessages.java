package com.cg.login.exception;

public class ExceptionMessages {
public static final String MESSAGE1="hello"; 
}
